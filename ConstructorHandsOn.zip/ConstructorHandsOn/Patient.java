package ConstructorHandsOn;

public class Patient {
	 String FirstName;
	 String LastName;
	 int age;
	 char Gender;
	 
	 
	 // Constructor  which initialize the values to the object Patient
	 public Patient() {
		 
		 this.FirstName="Anu";
		 this.LastName="Priya";
		 this.age=24;
		 this.Gender='F';
	 }

	 
}
