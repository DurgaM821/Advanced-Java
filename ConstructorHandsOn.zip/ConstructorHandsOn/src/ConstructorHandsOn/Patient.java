package ConstructorHandsOn;

public class Patient {
	 String FirstName;
	 String LastName;
	 int age;
	 char Gender;
	 
	 
	 // Constructor  which initialize the values to the object Patient
	 public Patient() {
		 
		 this.FirstName="Anu";
		 this.LastName="Priya";
		 this.age=24;
		 this.Gender='F';
		 System.out.println("Object is created");
		 
	 }
	 
	 
	 // constructor Overrriding --> same constructor but the paramters are different
	 
	 
	 public Patient( String FirstN,String LastN, int age, char Gender) {
		 this.FirstName=FirstN;
		 this.LastName=LastN;
		 this.age=age;
		 this.Gender=Gender;
	 }
 public int getAge() {
	 System.out.println("checkPoint1");
	 return age;
 }
 public char getGender() {
	 return Gender;
 }
	 
}
