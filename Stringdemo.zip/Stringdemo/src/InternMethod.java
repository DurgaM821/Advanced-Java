public class InternMethod {

	/*
	 * intern() Method
In Java, when we perform any operation using the intern() method, it returns a canonical representation for the string object. A pool is managed by a String class.

When the intern() method is executed, it checks whether the String equals to this String Object is in the pool.
If it is available, then the string from the pool is returned. Otherwise, this String object is added to the pool and a reference to this String object is returned.
It follows that for any two strings s and t, s.intern() == t.intern() is true if and only if s.equals(t) is true.
It is advised to use equals(), not ==, to compare two strings. This is because the == operator compares memory locations, while the equals() method compares the content stored in two objects. 
	 */
	
	
public static void main(String[] args) {
	String literal1="hello";
	String literal2=new String("hello"); // constructor
	
	System.out.println(literal1==literal2);
	
	// intern method 
	String literal3=literal2.intern();
	System.out.println(literal1==literal3);
	}
}