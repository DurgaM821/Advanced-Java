
import java.util.*;
public class StringConcatenator{
    public static void main(String[] args){
        
        String greeting="Hello,";
        String name="Alex.";
        String message=" Welcome to elite Java Club!";
        
        System.out.println(greeting.concat(name).concat(message));
    }
}