
public class ConcatMethod {

	public static void main(String[] args) {
		// https://www.javatpoint.com/java-string-concat
		
		String firstName="Rina";
		firstName=firstName+" "+ "sen";
		System.out.println(firstName);
		
		// concat method
		
		String name="Meenu";
		name=name.concat(firstName);
		System.out.println(name);
		
		String car="is a Nano car";
		System.out.println("TATA".concat(car));
		
	}

}
