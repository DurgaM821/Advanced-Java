package ConstructorHandsOn;
import java.util.*;
public class PatientMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        System.out.println("Hello world");
        
        // object is created by using a new Keyword
        
        Patient patient1=new Patient("Durga","Mohan",21,'F');
        Patient patient2=new Patient("Meena","Mohan",20,'f');
        /*System.out.println(patient.FirstName);
        System.out.println(patient.LastName);
        System.out.println(patient.age);
        System.out.println(patient.Gender);
        */
        
     //   System.out.println(patient.getAge());
      //  System.out.println(patient.getGender());
        //System.out.println(patient.Gender);
        
        
        /*---------------------------------CONSTRUCTOR OVER RIDING --------------------*/
        
        System.out.println(patient1.getAge());
        System.out.println(patient1.getGender());
        System.out.println("check point 2");
        System.out.println(patient2.getAge());
        System.out.println(patient2.getGender());
	}

}
